no stealies

You may edit this pack, honestly i can't stop that from happening - but please, do not redistribute without permission. just contact me on discord, my tag is Xonk#6472